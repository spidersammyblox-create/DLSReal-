package com.dlsreal

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File

class MainActivity : Activity() {

    companion object { private const val REQ_CAPTURE = 42; private const val REQ_MODEL = 43 }

    private var waitingOverlayPermission = false
    private lateinit var status: TextView
    private lateinit var renderBtn: Button
    private val prefs: SharedPreferences by lazy { getSharedPreferences("dlsreal", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (24 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(pad, pad, pad, pad)
            setBackgroundColor(Color.parseColor("#0E0E10"))
        }
        root.addView(TextView(this).apply {
            text = "DLS Real"
            textSize = 30f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = "1) Escolha seus jogos.\n2) Permita o acesso de uso (para saber quando você entra no jogo).\n3) Toque em Ativar e, na janela de gravação, escolha \"Toda a tela\".\n\nNo modo AUTO os shaders ligam sozinhos só dentro dos jogos escolhidos e desligam fora deles.\n\nDois modos: Shaders (leve, se adapta ao jogo) e IA por quadro (uma rede neural em cada frame, deixa ainda mais realista, mas pesa mais e precisa de um modelo .tflite importado)."
            textSize = 14f
            setTextColor(Color.parseColor("#B0B0B8"))
            gravity = Gravity.CENTER
            setPadding(0, pad / 2, 0, pad / 2)
        })
        status = TextView(this).apply {
            textSize = 13f
            setTextColor(Color.parseColor("#FFB74D"))
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, pad / 2)
        }
        root.addView(status)
        root.addView(Button(this).apply {
            text = "Escolher jogos"
            setOnClickListener { pickGames() }
        })
        renderBtn = Button(this).apply { setOnClickListener { toggleRender() } }
        root.addView(renderBtn)
        root.addView(Button(this).apply {
            text = "Importar modelo de IA (.tflite)"
            setOnClickListener { pickModel() }
        })
        root.addView(Button(this).apply {
            text = "Permitir acesso de uso"
            setOnClickListener { openUsageSettings() }
        })
        root.addView(Button(this).apply {
            text = "Ativar"
            setOnClickListener { activate() }
        })
        root.addView(Button(this).apply {
            text = "Desativar"
            setOnClickListener { stopService(Intent(this@MainActivity, OverlayService::class.java)) }
        })
        setContentView(root)
    }

    private fun refreshStatus() {
        val n = (prefs.getStringSet("games", emptySet()) ?: emptySet()).size
        val usage = if (UsageAccess.granted(this)) "permitido ✓" else "falta permitir"
        val ai = prefs.getInt("render", 0) == 1
        val model = if (AiEnhancer.hasModel(this)) "importado ✓" else "falta importar (só p/ modo IA)"
        renderBtn.text = if (ai) "Modo: IA por quadro (toque p/ trocar)" else "Modo: Shaders (toque p/ trocar)"
        status.text = "Jogos escolhidos: $n\nAcesso de uso: $usage\nModelo de IA: $model\nO modo vale na próxima ativação (ou troque na aba ⚙)"
    }

    private fun toggleRender() {
        val cur = prefs.getInt("render", 0)
        prefs.edit().putInt("render", if (cur == 1) 0 else 1).apply()
        refreshStatus()
    }

    @Suppress("DEPRECATION")
    private fun pickModel() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*")
        startActivityForResult(i, REQ_MODEL)
    }

    private fun importModel(uri: Uri) {
        Toast.makeText(this, "Importando modelo...", Toast.LENGTH_SHORT).show()
        Thread {
            val tmp = File(filesDir, "enhancer.tmp")
            val msg = try {
                contentResolver.openInputStream(uri)!!.use { inp -> tmp.outputStream().use { inp.copyTo(it) } }
                val head = ByteArray(8)
                val n = tmp.inputStream().use { it.read(head) }
                if (n < 8 || String(head, 4, 4, Charsets.US_ASCII) != "TFL3") {
                    tmp.delete(); "Esse arquivo não parece um modelo .tflite."
                } else {
                    val dst = AiEnhancer.modelFile(this)
                    dst.delete(); tmp.renameTo(dst); "Modelo importado ✓"
                }
            } catch (e: Exception) { tmp.delete(); "Falha ao importar: ${e.message}" }
            runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_LONG).show(); refreshStatus() }
        }.start()
    }

    @Suppress("DEPRECATION")
    private fun pickGames() {
        val pm = packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first != packageName }
            .distinctBy { it.first }
            .sortedBy { it.second.lowercase() }
        if (apps.isEmpty()) {
            Toast.makeText(this, "Nenhum app encontrado.", Toast.LENGTH_LONG).show()
            return
        }
        val saved = prefs.getStringSet("games", emptySet()) ?: emptySet()
        val checked = BooleanArray(apps.size) { apps[it].first in saved }
        AlertDialog.Builder(this)
            .setTitle("Escolha seus jogos")
            .setMultiChoiceItems(apps.map { it.second }.toTypedArray(), checked) { _, i, v -> checked[i] = v }
            .setPositiveButton("Salvar") { _, _ ->
                val set = HashSet<String>()
                for (i in apps.indices) if (checked[i]) set.add(apps[i].first)
                prefs.edit().putStringSet("games", set).apply()
                refreshStatus()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun openUsageSettings() {
        try {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS, Uri.parse("package:$packageName")))
        } catch (e: Exception) {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        }
        Toast.makeText(this, "Ache \"DLS Real\" na lista e permita.", Toast.LENGTH_LONG).show()
    }

    private fun activate() {
        if (!Settings.canDrawOverlays(this)) {
            waitingOverlayPermission = true
            Toast.makeText(this, "Permita \"Exibir sobre outros apps\" e volte.", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            return
        }
        requestCapture()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        requestCapture()
    }

    private fun requestCapture() {
        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION")
        startActivityForResult(mgr.createScreenCaptureIntent(), REQ_CAPTURE)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_MODEL) {
            val u = data?.data
            if (resultCode == RESULT_OK && u != null) importModel(u)
            return
        }
        if (requestCode == REQ_CAPTURE && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, OverlayService::class.java)
                .putExtra("code", resultCode)
                .putExtra("data", data)
            startForegroundService(i)
            Toast.makeText(this, "Pronto! Abra o jogo: no AUTO os shaders ligam sozinhos.", Toast.LENGTH_LONG).show()
            moveTaskToBack(true)
        } else if (requestCode == REQ_CAPTURE) {
            Toast.makeText(this, "A captura de tela é necessária para os shaders.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
        if (waitingOverlayPermission && Settings.canDrawOverlays(this)) {
            waitingOverlayPermission = false
            activate()
        }
    }
}
